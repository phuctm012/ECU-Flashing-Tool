# ==================================================
# Test Connection Worker
# ==================================================
#
# QObject-based worker (run on a QThread, same pattern as
# FlashWorker) driving a safe, read-only connectivity probe
# as cli.py's cmd_test_connection() — connects, Extended
# session (+ functional pre-steps for the Suzuki sequence),
# then reads ECU Identification. Never touches Programming
# session, Security Access, Erase Memory, TransferData, or
# any write. Always tries to restore Default session before
# finishing, regardless of where it stopped — the try/finally
# below is exactly why this doesn't go through the linear,
# abort-on-first-failure FlashStep sequence (see CLAUDE.md).
#
# Only reuses FlashWorker for its CAN/UDS connection setup
# (_setup_uds_client()/_cleanup()) — everything else is driven
# directly against the resulting UdsClient, same as cli.py.
# ==================================================

from PySide6.QtCore import QObject, Signal

from core.flash_controller import FlashWorker
from communication.uds_client import UdsClient, UdsDeadlineError

TEST_CONNECTION_DIDS = [
    (UdsClient.DID_SUPPLIER_SW_VERSION, "System Supplier ECU SW Version"),
    (UdsClient.DID_HW_VERSION, "Vehicle Manufacturer ECU HW Number"),
    (UdsClient.DID_SERIAL_NUMBER, "ECU Serial Number"),
    (UdsClient.DID_ECU_SW_NUMBER, "Vehicle Manufacturer ECU SW Number"),
    (UdsClient.DID_SW_VERSION, "Vehicle Manufacturer ECU SW Version"),
]


class TestConnectionWorker(QObject):

    # ==========================================
    # Signals
    # ==========================================

    step_message = Signal(str)         # "Extended Session (Network)"
    trace_message = Signal(str)        # narrative trace log
    trace_row = Signal(dict)           # paired UDS request/response row
    ecu_info_message = Signal(dict)    # ECU identification data
    finished = Signal(bool, str)       # (passed, summary message)

    # ==========================================
    # Constructor
    # ==========================================

    def __init__(
        self,
        use_virtual=True,
        security_dll_path=None,
        security_dll_signature="auto",
        security_dll_variant="",
        run_timeout=None,
        functional=False,
        can_channel=0,
        can_serial=None,
        can_tx_id=0x778,
        can_rx_id=0x788,
        can_bitrate=500000,
        can_fd=False,
        can_data_bitrate=2000000,
        functional_id=0x700,
    ):
        super().__init__()

        self._use_virtual = use_virtual
        self._security_dll_path = security_dll_path
        self._functional = functional
        self._can_channel = can_channel
        self._can_serial = can_serial
        self._can_tx_id = can_tx_id
        self._can_rx_id = can_rx_id
        self._can_bitrate = can_bitrate
        self._can_fd = can_fd
        self._can_data_bitrate = can_data_bitrate
        self._functional_id = functional_id
        self._run_timeout = run_timeout

        # None / "connection" / "timeout" / "probe" — read by
        # cli.py for its exit code.
        self.failure_kind = None

        # The FlashWorker whose _setup_uds_client()/_cleanup() run()
        # borrows. Built and wired HERE, on the thread that constructs
        # this worker (the main thread), never inside run(): a
        # `connect()` takes one of Qt's pooled signal/slot mutexes
        # while the worker thread holds the GIL, which is one half
        # of the mutex <-> GIL lock-order inversion documented in
        # gui/worker_teardown.py (the other half is the main thread
        # destroying any Python-created QObject with the GIL
        # released). It was a real, intermittent deadlock in
        # Parallel Flash — Phase 4.116. The inner worker stays on
        # the main thread; run() only calls its methods and emits
        # its signals, both of which are thread-safe.
        self._worker = FlashWorker(
            steps=[],
            datablocks=[],
            use_virtual=use_virtual,
            security_dll_path=security_dll_path,
            security_dll_signature=security_dll_signature,
            security_dll_variant=security_dll_variant,
            can_channel=can_channel,
            can_serial=can_serial,
            can_tx_id=can_tx_id,
            can_rx_id=can_rx_id,
            can_bitrate=can_bitrate,
            can_fd=can_fd,
            can_data_bitrate=can_data_bitrate,
            functional_id=functional_id,
            run_timeout=run_timeout,
        )
        self._worker.trace_message.connect(self.trace_message)
        self._worker.trace_row.connect(self.trace_row)

    # ==========================================
    # Run (called on the worker thread)
    # ==========================================

    def run(self):

        worker = self._worker
        self.failure_kind = None

        # FlashWorker.run() normally arms this; the probe calls
        # _setup_uds_client() directly, so arm it here instead —
        # otherwise --timeout would not cover a probe at all.
        worker.arm_deadline()

        try:
            worker._setup_uds_client()
        except Exception as e:
            # Same reasoning as the finally: below — _cleanup() also
            # breaks the worker <-> UdsClient cycle so this local
            # worker dies by refcount when run() returns, not on
            # some other thread's garbage collection.
            worker._cleanup()
            self.failure_kind = "connection"
            self.finished.emit(False, f"Connection failed: {e}")
            return

        uds = worker._uds_client
        ok = True
        message = "Connection test PASSED — ECU reachable."

        try:
            if self._functional:
                uds.diagnostic_session_control(0x03, functional=True)
                self.step_message.emit("Extended Session (Network)")
                uds.control_dtc_setting(
                    setting_type=0x02, option_record=bytes([0x00]),
                    functional=True,
                )
                self.step_message.emit(
                    "Disable DTC Settings (Network)"
                )
                uds.communication_control(
                    control_type=0x03, communication_type=0x01,
                    functional=True,
                )
                self.step_message.emit(
                    "Disable Normal Communication (Network)"
                )
            else:
                uds.diagnostic_session_control(0x03)
                self.step_message.emit("Extended Session")

            info = {}
            for did, name in TEST_CONNECTION_DIDS:
                try:
                    data = uds.read_data_by_identifier(did)
                    try:
                        value = data.decode("ascii").strip('\x00')
                    except (UnicodeDecodeError, ValueError):
                        value = data.hex().upper()
                    info[name] = value
                    self.step_message.emit(
                        f"Read DID 0x{did:04X}: {name} = {value}"
                    )
                except UdsDeadlineError:
                    # Per-DID failures are tolerated (an ECU may
                    # simply not support one), but the run's
                    # deadline is not a property of this DID —
                    # let it end the probe.
                    raise
                except Exception as e:
                    info[name] = f"N/A ({e})"
                    self.step_message.emit(
                        f"Read DID 0x{did:04X}: {name} = N/A"
                    )
            self.ecu_info_message.emit(info)

        except Exception as e:
            ok = False
            self.failure_kind = (
                "timeout" if isinstance(e, UdsDeadlineError)
                else "probe"
            )
            message = f"Connection test FAILED: {e}"

        finally:
            # Best-effort cleanup: restore Default session (and
            # re-enable DTC/Communication if we disabled them),
            # regardless of where the probe above stopped.
            try:
                if self._functional:
                    uds.communication_control(
                        control_type=0x00, communication_type=0x01,
                        functional=True,
                    )
                    uds.control_dtc_setting(
                        setting_type=0x01, functional=True
                    )
                uds.diagnostic_session_control(
                    0x01, functional=self._functional
                )
                self.step_message.emit("Restored Default session")
            except Exception:
                pass

            worker._cleanup()

        self.finished.emit(ok, message)
